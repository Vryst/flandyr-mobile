

extends ColorRect

func _ready():
    position = Vector2.ZERO
    size = get_viewport_rect().size
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
